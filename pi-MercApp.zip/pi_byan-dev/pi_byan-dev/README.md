# MercApp-pi

PI - Qualidade de Software

Integrantes:

Nome: Beatriz Dias Lopes

Nome: Yan Damascena



## Banco de Dados:

DATABASE QUERY (postgreSQL in Supabase):

USE DATABASE postgres (SUPABASE somente aceita database padrão postgres na versão gratuita);

CREATE TABLE IF NOT EXISTS clientes (
id SERIAL PRIMARY KEY,
nome VARCHAR(100) NOT NULL,
cpf VARCHAR(20) NOT NULL UNIQUE,
data_de_nascimento VARCHAR(10) NOT NULL
);
