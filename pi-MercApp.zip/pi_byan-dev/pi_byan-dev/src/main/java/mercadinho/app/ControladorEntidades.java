package mercadinho.app;

public class ControladorEntidades {

    public Cliente find(Class<Cliente> clienteClass, int i) {
        return null;
    }
}
